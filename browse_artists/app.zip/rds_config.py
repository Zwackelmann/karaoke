host = "karaoke.ctnzp65h4qap.eu-central-1.rds.amazonaws.com"
db_username = "karaoke"
db_password = "m2paotI-01"
db_name = "karaoke"